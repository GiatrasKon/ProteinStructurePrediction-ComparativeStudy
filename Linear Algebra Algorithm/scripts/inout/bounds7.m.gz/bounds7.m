function B = bounds7()
c = 13/5;
x = .5;
y = 2.5;

B = [ 0 1 1 1 1 1 1 1; 
      1 0 1 c y y c 1; 
      1 1 0 1 c y y c; 
      1 c 1 0 1 c y y;
      1 x c 1 0 1 c y; 
      1 x x c 1 0 1 c; 
      1 c x x c 1 0 1;
      1 1 c x x c 1 0];

