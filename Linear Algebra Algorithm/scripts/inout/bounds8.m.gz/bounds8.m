% distances squared for cyclo8

function B = bounds8()
c = 13/5;
x = 0; 	% x = .5;
y = 9;	% y = 2.5;

B = [ 0 1 1 1 1 1 1 1 1; 
      1 0 1 c y y y c 1; 
      1 1 0 1 c y y y c; 
      1 c 1 0 1 c y y y;
      1 x c 1 0 1 c y y; 
      1 x x c 1 0 1 c y; 
      1 x x x c 1 0 1 c;
      1 c x x x c 1 0 1;
      1 1 c x x x c 1 0];

