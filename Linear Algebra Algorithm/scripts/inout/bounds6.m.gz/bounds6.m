function B = bounds6()

c = 8/3;
x = (1.69)^2;
y = (1.96)^2;

B = [ 0 1 1 1 1 1 1; 
      1 0 1 c y c 1; 
      1 1 0 1 c y c; 
      1 c 1 0 1 c y;
      1 x c 1 0 1 c; 
      1 c x c 1 0 1; 
      1 1 c x c 1 0 ];

